# Medical YouTube Optimizer - HealthGuard

A HIPAA-compliant Chrome extension for analyzing medical content on YouTube with privacy-preserving features and Tamil language support for Ayurvedic medicine.

## 🚨 Important Medical Disclaimer

**THIS EXTENSION IS FOR INFORMATIONAL PURPOSES ONLY**

- ❌ **NOT** intended as medical advice, diagnosis, or treatment
- ❌ **NOT** a substitute for professional medical consultation
- ❌ **NOT** validated by medical professionals
- ✅ **Always consult qualified healthcare professionals before making medical decisions**
- ✅ **For medical emergencies, contact emergency services immediately**

## ✨ Features

### 🔍 Medical Content Analysis
- Automated detection of medical terms and concepts
- Risk assessment for potentially harmful medical claims
- Content categorization (General Health, Ayurveda, Modern Medicine, Mental Health, Emergency)
- Real-time overlay notifications with analysis results

### � HIPAA Compliance & Security
- **AES-256 encryption** for all medical data
- **Local storage only** - no external servers
- **Audit logging** for all data access
- **Data minimization** principles
- **Automatic data expiration** (90 days default)
- **User consent management**

### � Language Support
- **Tamil language** processing for Ayurvedic content
- **Auto-detection** of content language
- **Medical term recognition** in multiple languages
- **Translation capabilities** (in development)

### 🏥 Trusted Source Verification
- Built-in database of verified medical sources
- Real-time source credibility checking
- Customizable trusted source list
- Warnings for unverified medical claims

### 📱 User Experience
- Modern, accessible interface
- Real-time analysis with progress indicators
- Customizable settings and preferences
- Export/import data functionality

## 🚀 Quick Start

### Installation

1. **Clone or download this repository**
   ```bash
   git clone https://github.com/Rishpraveen/Youtube_Context_Analysis_using_API.git
   ```

2. **Load the extension in Chrome**
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" in the top right corner
   - Click "Load unpacked" and select the folder containing this extension

3. **Configure API keys**
   - Click the extension icon to open the popup
   - Go to options and configure your API keys (see [API Setup](#-api-setup) below)

### API Setup

#### YouTube API Key (Required)
1. Go to the [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the YouTube Data API v3
4. Create credentials (API key)
5. Copy and paste the API key in the extension options

#### Choose Your LLM Provider

**Option 1: OpenAI API Key**
- Go to [OpenAI API Keys](https://platform.openai.com/api-keys)
- Create an account or log in
- Create a new secret key
- Copy and paste the key in the extension options

**Option 2: Hugging Face API Key (Free Alternative)**
- Go to [Hugging Face](https://huggingface.co/settings/tokens)
- Create an account or log in
- Create a new access token
- Copy and paste the token in the extension options

**Option 3: Google Gemini API Key (Free Tier Available)**
- Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
- Create an account or log in
- Create a new API key
- Copy and paste the key in the extension options

**Option 4: Ollama (Completely Free, Local Option)**
- Install [Ollama](https://ollama.ai/) on your local machine
- Start the Ollama server
- Configure the endpoint URL (default: `http://localhost:11434`)
- Select your preferred model in the extension options

## 📖 Usage Guide

### Getting Transcripts
1. Navigate to any YouTube video or Short
2. Click the extension icon
3. Go to the "Transcript" tab
4. Click "Get Transcript" or use **Ctrl+T**
5. View extracted transcripts in multiple languages (if available)

### Analyzing Comments
1. In the "Comments" tab
2. Click "Analyze Comments" or use **Ctrl+C**
3. Configure batch size and maximum comments in options for optimal performance
4. View sentiment analysis and key themes

### RAG Analysis
1. Go to the "RAG Analysis" tab
2. Enter your question about the video content
3. Use **Ctrl+R** to focus on the query input
4. Get AI-powered answers based on the transcript

### Keyboard Shortcuts
- **Ctrl+1**: Switch to Transcript tab
- **Ctrl+2**: Switch to Comments tab  
- **Ctrl+3**: Switch to RAG Analysis tab
- **T**: Get transcript (when in Transcript tab)
- **C**: Analyze comments (when in Comments tab)
- **R**: Focus on RAG query input (when in RAG tab)

### Exporting Results
Use the download buttons next to each analysis section:
- **Transcript**: Exports as a text file (.txt)
- **Comment Analysis**: Exports as an HTML report
- **RAG Analysis**: Exports as an HTML report

## ⚙️ Configuration

### Performance Settings
- **Comment Batch Size**: Controls how many comments are processed at once (lower = less RAM usage)
- **Max Comments**: Limits total comments to analyze (lower = faster processing)
- **Chunk Size**: Size of transcript chunks for RAG (smaller = less memory usage)

### Language Settings
- **Fetch All Languages**: When enabled, fetches captions in all available languages
- **Preferred Languages**: Select languages in order of preference (when "Fetch All Languages" is disabled)
- **Auto-Generated Translations**: Include auto-translated captions (may be less accurate)

### Manual Mode
If automatic transcript extraction fails:
1. Go to extension options
2. Enable "Use Manual Mode"
3. Optionally paste a default transcript
4. When using the extension, you'll be prompted to paste the transcript manually

## 🏥 **NEW: Medical Analysis Features**

### 🎬 Advanced Subtitle Extraction
- **Intelligent Fallback System**: Multiple methods to extract subtitles when transcripts aren't available
- **Live Caption Capture**: Extracts real-time captions from YouTube video player
- **YouTube Internal Data Access**: Taps into YouTube's internal caption tracks
- **Auto-Caption Enablement**: Automatically enables captions if they're available but not showing

### 🌍 Language Detection & Translation
- **Automatic Language Detection**: Uses Hugging Face's `facebook/fasttext-language-identification` model
- **Free Translation to English**: Leverages `Helsinki-NLP/opus-mt-mul-en` for multi-language translation
- **Translation Transparency**: Shows users what language was detected and translated
- **Fallback Handling**: Uses original text if translation fails

### 🏥 Medical Content Analysis
- **Medical Entity Recognition**: Uses `d4data/biomedical-ner-all` to identify medical terms, drugs, conditions
- **Health Claim Extraction**: Powered by `microsoft/BiomedNLP-PubMedBERT` for medical text understanding
- **Personalized Risk Assessment**: Analyzes claims against user's health profile (medications, conditions)
- **Drug Interaction Warnings**: Checks for dangerous interactions with user's current medications
- **Privacy-First Design**: All health data encrypted and stored locally, never sent to external APIs

### 🔒 Privacy & Security
- **Local Health Data**: Your medical information never leaves your browser
- **Encrypted Storage**: Health profiles encrypted in browser's local storage
- **Open Source Models**: Uses transparent, open-source AI models via Hugging Face
- **No Tracking**: No user data collection or analytics
- **Free to Use**: Completely free with Hugging Face's free tier API access

## 🛠️ Technical Details

### Supported YouTube Formats
- **Standard YouTube Videos**: `https://www.youtube.com/watch?v=VIDEO_ID`
- **YouTube Shorts**: `https://www.youtube.com/shorts/VIDEO_ID`

The extension automatically detects the video format and extracts the video ID accordingly.

### Browser Player Caption Extraction
When the YouTube API doesn't have captions for certain languages:
- **Automatic Fallback**: Enabled by default, triggers when API extraction fails
- **Real-time Extraction**: Captures captions as they appear in the player
- **Multi-language Support**: Can extract multiple languages sequentially
- **Manual Control**: Can be disabled in settings if not desired

### Caching System
- Transcripts are cached for 1 hour
- Analysis results are cached based on the selected API provider
- Cache is automatically cleaned to prevent excessive memory usage

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details on:
- How to report bugs
- How to suggest features
- How to submit pull requests
- Code style guidelines

## 🛡️ Security

For security concerns, please see our [Security Policy](SECURITY.md).

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🌟 Support

If you find this project useful, please consider:
- ⭐ Starring this repository
- 🐛 Reporting bugs through [Issues](https://github.com/Rishpraveen/Youtube_Context_Analysis_using_API/issues)
- 💡 Suggesting new features
- 🔄 Sharing with others

## 🔧 Troubleshooting

### Common Issues

**API Keys Not Working**
- Use the "Test API" buttons in options to verify your keys

**High Memory Usage**
- Reduce batch size and chunk size in the options

**Transcript Extraction Fails**
- Switch to manual mode and paste the transcript manually
- Check if the video has captions available

**Extension Closing**
- This has been fixed in recent updates - popup now stays open during operations

**Slow Analysis**
- Enable caching and consider using a more efficient API provider
- Reduce the number of comments being analyzed

**YouTube Shorts Issues**
- Ensure you're on a valid YouTube video or Short page
- Extension now supports both `/watch?v=` and `/shorts/` URLs

**Video ID Not Detected**
- Make sure you're on `youtube.com/watch?v=` or `youtube.com/shorts/` URLs
- Refresh the page and try again

### Privacy Notice

This extension only processes data for the currently active YouTube video. No data is stored on external servers, and API keys are stored locally in your browser.

## 🏗️ Built With

- **JavaScript** - Core functionality
- **Chrome Extension APIs** - Browser integration
- **YouTube Data API v3** - Video and transcript data
- **Multiple AI APIs** - OpenAI, Hugging Face, Gemini, Ollama
- **RAG Technology** - Retrieval-Augmented Generation

## 🔗 Links

- [Chrome Web Store](https://chrome.google.com/webstore) (Coming Soon)
- [Issues](https://github.com/Rishpraveen/Youtube_Context_Analysis_using_API/issues)
- [Discussions](https://github.com/Rishpraveen/Youtube_Context_Analysis_using_API/discussions)

---

**Made with ❤️ by [Rishpraveen](https://github.com/Rishpraveen)**

*⚡ Powered by AI • 🎯 Built for Researchers • 🌍 Multi-language Ready*
