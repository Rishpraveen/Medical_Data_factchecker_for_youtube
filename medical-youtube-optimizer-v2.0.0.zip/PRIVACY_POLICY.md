# Privacy Policy - Medical YouTube Optimizer (HealthGuard)

**Effective Date: August 1, 2025**
**Last Updated: August 1, 2025**

## Overview

Medical YouTube Optimizer (HealthGuard) is committed to protecting your privacy and medical data. This Privacy Policy explains how we collect, use, protect, and handle your information when you use our Chrome extension.

## Important Medical Data Notice

⚠️ **This extension processes medical information. All medical data is handled according to HIPAA-compliant practices and is encrypted before storage.**

## Information We Collect

### Data We Process Locally
- **Video Transcripts**: Text content from YouTube videos you analyze
- **Medical Terms**: Identified medical terms and concepts from video content
- **Analysis Results**: Risk assessments and content categorizations
- **User Preferences**: Settings and configuration choices
- **Consent Records**: Your privacy and data processing consent status

### Data We Do NOT Collect
- ❌ Personal identifying information
- ❌ YouTube account information
- ❌ Browsing history outside of analyzed videos
- ❌ Medical records or personal health information
- ❌ Location data
- ❌ Analytics or tracking data

## How We Use Your Information

### Primary Uses
1. **Medical Content Analysis**: Analyze video content for medical terms and risk factors
2. **Risk Assessment**: Provide warnings about potentially harmful medical claims
3. **Language Processing**: Support Tamil language content and Ayurvedic medicine analysis
4. **Source Verification**: Check credibility of medical sources
5. **User Experience**: Remember your preferences and settings

### Data Processing Principles
- **Purpose Limitation**: Data is only used for stated medical analysis purposes
- **Data Minimization**: We collect only essential data needed for functionality
- **Storage Limitation**: Data automatically expires after 90 days (configurable)
- **Consent-Based**: All processing requires your explicit consent

## Data Storage and Security

### Local Storage Only
- ✅ All data is stored locally on your device
- ✅ No data is transmitted to external servers
- ✅ No cloud storage or remote databases used
- ✅ Complete user control over data deletion

### Encryption and Security
- **AES-256 Encryption**: All medical data is encrypted before storage
- **Secure Key Management**: Encryption keys are generated locally
- **Audit Logging**: All data access is logged for security
- **Automatic Expiration**: Data automatically deleted after retention period

## HIPAA Compliance

### Compliance Measures
- **Administrative Safeguards**: Policies for data access and handling
- **Physical Safeguards**: Local-only storage prevents unauthorized access
- **Technical Safeguards**: Encryption, access controls, and audit logging
- **Breach Notification**: Procedures for handling any security incidents

### User Rights Under HIPAA
- Right to access your medical data
- Right to request amendments to your data
- Right to restrict data processing
- Right to receive data in portable format
- Right to file complaints about data handling

## Your Privacy Rights

### Data Control Rights
- **Access**: View all stored medical data through export function
- **Correction**: Modify or update your preferences and settings
- **Deletion**: Clear all data at any time through settings
- **Portability**: Export your data in JSON format
- **Consent Withdrawal**: Revoke consent for data processing at any time

### How to Exercise Rights
1. **Access Data**: Use the "Export Data" function in settings
2. **Delete Data**: Use the "Clear All Data" function in settings
3. **Modify Consent**: Update consent preferences in Privacy tab
4. **Contact Us**: Email privacy@healthguard-extension.com for assistance

## Consent Management

### Required Consents
- **Medical Analysis**: Consent to analyze video content for medical information
- **Data Storage**: Consent to store analysis results for history
- **Language Processing**: Consent to process Tamil language content

### Consent Characteristics
- **Freely Given**: You can use basic features without all consents
- **Specific**: Separate consent for each type of data processing
- **Informed**: Clear explanation of what each consent enables
- **Withdrawable**: Easy to revoke consent at any time

## Third-Party Services

### No Third-Party Data Sharing
- ❌ We do not share data with third parties
- ❌ No analytics services or tracking
- ❌ No advertising networks
- ❌ No social media integration

### Chrome Extension APIs
- We only use Chrome APIs necessary for core functionality
- `activeTab`: Access current YouTube tab for analysis
- `scripting`: Inject content script for video analysis
- `storage`: Store encrypted data locally

## Children's Privacy

This extension is not intended for use by children under 13 years of age. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us immediately.

## Data Breach Notification

### Our Commitment
- **24-Hour Detection**: Automated monitoring for security issues
- **72-Hour Notification**: Users notified within 72 hours of any breach
- **Immediate Containment**: Automatic security measures activated
- **Full Transparency**: Complete disclosure of breach details and impact

### What We Monitor
- Unauthorized access attempts
- Data corruption or loss
- System vulnerabilities
- Extension compromise

## International Data Transfers

Since all data is stored locally on your device, there are no international data transfers. Your data never leaves your device and is not transmitted to any servers, regardless of location.

## Changes to This Privacy Policy

### Notification Process
- **Email Notification**: Registered users notified of material changes
- **In-Extension Notice**: Prominent notice displayed in extension interface
- **Website Updates**: Updated policy posted on our website
- **Version History**: Previous versions archived and accessible

### Your Options After Changes
- Continue using the extension under new terms
- Withdraw consent for data processing
- Export your data before policy changes take effect
- Contact us with questions or concerns

## Contact Information

### Privacy Questions
**Email**: privacy@healthguard-extension.com
**Response Time**: Within 48 hours for privacy inquiries

### Data Protection Officer
**Email**: dpo@healthguard-extension.com
**Phone**: +1-555-PRIVACY (774-8229)

### HIPAA Compliance Officer
**Email**: hipaa@healthguard-extension.com
**Address**: 
HealthGuard Privacy Office
1234 Medical Privacy Ave
Privacy City, PC 12345
United States

## Regulatory Compliance

### Applicable Laws
- **HIPAA** (Health Insurance Portability and Accountability Act)
- **GDPR** (General Data Protection Regulation) - for EU users
- **CCPA** (California Consumer Privacy Act) - for California users
- **State Privacy Laws** - as applicable by user location

### Compliance Certifications
- HIPAA Security Rule compliant
- SOC 2 Type II controls implemented
- ISO 27001 security standards followed

## Transparency Report

We commit to publishing an annual transparency report including:
- Number of users and data processing activities
- Security incidents and responses
- Privacy rights requests and responses
- Compliance audit results

---

**Questions or Concerns?**

If you have any questions about this Privacy Policy or our data practices, please contact us at privacy@healthguard-extension.com. We are committed to addressing your privacy concerns promptly and transparently.

**Medical Emergency Disclaimer**: This privacy policy does not apply to medical emergencies. If you are experiencing a medical emergency, contact emergency services immediately (911 in US, 999 in UK, 112 in EU).
